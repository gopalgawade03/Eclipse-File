package com.hdfcergo.campaign.allinoneproduct;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class travel {

public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/all-in-one-product-new");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//div[@class='InsuranceIcon InsuranceIcon4']")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("btnSubmitt")).click();

	}

}
