package com.hdfcergo.campaign.home;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BuyOnline_validation_2ndURL {

public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/home-insurance-detail");
		Thread.sleep(2000);
		
		//Inspect form
		
		WebElement nameTextBox= driver.findElement(By.id("txtName"));
		nameTextBox.isDisplayed();
		nameTextBox.isEnabled();
		nameTextBox.sendKeys("hdfc ergo");
		
		WebElement emailTexttBox= driver.findElement(By.id("txtEmail"));
		emailTexttBox.isDisplayed();
		emailTexttBox.isEnabled();
		emailTexttBox.sendKeys("text@gmail.com");
		
		WebElement moNumberTextBox= driver.findElement(By.id("txtMobno"));
		moNumberTextBox.isDisplayed();
		moNumberTextBox.isEnabled();
		moNumberTextBox.sendKeys("8451965366");
		
		WebElement tenure= driver.findElement(By.xpath("//label[normalize-space()='2 - 5 years']"));
		tenure.isDisplayed();
		tenure.isEnabled();
		tenure.click();
		Thread.sleep(2000);
		
		WebElement buyOnlineBtn= driver.findElement(By.xpath("//input[@id='btnBuyOnlineDivMandatory']"));
		buyOnlineBtn.isDisplayed();
		buyOnlineBtn.isEnabled();
		buyOnlineBtn.click();
	}

}
