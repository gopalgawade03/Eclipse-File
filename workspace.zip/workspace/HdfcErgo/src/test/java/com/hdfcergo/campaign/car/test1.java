package com.hdfcergo.campaign.car;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test1 {

	public static void main(String[] args) throws Exception {
		
		//provide the path of chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		
		//Instantiate chrome driver class
		WebDriver driver = new ChromeDriver();
		
		//to hit URL 
		driver.get("https://uatsf.hdfcergo.com/campaigns/buy-vehicle-insurance-online");
		Thread.sleep(2000);
		

	}

}
