package com.hdfcergo.campaign.car;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class car_buy_Vehicle_Insurance_Online_1st {

	public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://uatsf.hdfcergo.com/campaigns/buy-vehicle-insurance-online");
		Thread.sleep(2000);
		
		
	    //Inspect Input box
		WebElement inputBox= driver.findElement(By.id("RegistrationNumber"));
		inputBox.isDisplayed();
		inputBox.isEnabled();
		inputBox.sendKeys("MH 14 CC 2923");
		Thread.sleep(2000);
		
		//Inspect Get Quote button
		WebElement getQuoteBtn= driver.findElement(By.xpath("//button[@class='cust-btn-red1 mbx10 mtx10']"));
		getQuoteBtn.isDisplayed();
		getQuoteBtn.isEnabled();
		getQuoteBtn.click();
		Thread.sleep(2000);
		
		driver.navigate().back();	
		}

}
