package com.hdfcergo.campaign.allinoneproduct;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class car {

public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/all-in-one-product-new");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//div[@class='InsuranceIcon InsuranceIcon1']")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtName")).sendKeys("hdfc ergo");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtMobno")).sendKeys("8451965366");
		Thread.sleep(1000);
		
		driver.findElement(By.id("txtEmail")).sendKeys("test@gmail.com");
		Thread.sleep(1000);
		
		WebElement drp= driver.findElement(By.id("CarCity"));
		Select drpText=new Select(drp);
		drpText.selectByVisibleText("AGRA");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//div[@class='container']//div[@class='col-md-12 text-center']")).click();
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("//button[@id='btnSubmit']")).click();
		

	}

}
