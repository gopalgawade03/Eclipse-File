package com.hdfcergo.campaign.health;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class getFreeQuote_optimaRestore_2ndURL {

public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/optima-restore");
		Thread.sleep(2000);
		
		driver.findElement(By.id("txtName")).sendKeys("hdfc ergo");Thread.sleep(1000);
		driver.findElement(By.id("txtEmail")).sendKeys("test@gmail.com");Thread.sleep(1000);
		driver.findElement(By.id("txtMobno")).sendKeys("8451965366");Thread.sleep(1000);
		
		WebElement drpCity= driver.findElement(By.id("txtCity"));
		Select drpText=new Select(drpCity);
		drpText.selectByVisibleText("AGRA");Thread.sleep(1000);
		
		WebElement drpPlan= driver.findElement(By.id("txtSI"));
		Select drpOpt=new Select(drpPlan);
		drpOpt.selectByVisibleText("Family Plan");Thread.sleep(1000);
		
		driver.findElement(By.xpath("//input[@id='btnSubmit']")).click();

	}

}
