package com.hdfcergo.campaign.allinoneproduct;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class bike_getQuoteButton {

public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/all-in-one-product-new");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//div[@class='InsuranceIcon InsuranceIcon2']")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("RegistrationNumber1")).sendKeys("mH 04 HC 4181");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//div[@class='BikeBox col-sm-12 popBox']//button[@class='btn btn-full btn-square w20 btn-bike'][normalize-space()='GET Quote']")).click();
		

	}

}
