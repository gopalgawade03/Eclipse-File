package com.hdfcergo.campaign.allinoneproduct;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class health {

public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/all-in-one-product-new");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//div[@class='InsuranceIcon InsuranceIcon3']")).click();Thread.sleep(1000);
		driver.findElement(By.id("txtName1")).sendKeys("hdfc ergo");Thread.sleep(1000);
		driver.findElement(By.id("txtMobno1")).sendKeys("8451965366");Thread.sleep(1000);
		driver.findElement(By.id("txtEmail1")).sendKeys("test@gmail.com");Thread.sleep(1000);
		
		WebElement drp= driver.findElement(By.id("HealthCity"));
		Select drpText=new Select(drp);
		drpText.selectByVisibleText("AGRA");Thread.sleep(1000);
		
		driver.findElement(By.xpath("//label[normalize-space()='Above 15 Lakhs']")).click();Thread.sleep(1000);
		driver.findElement(By.xpath("//button[@id='Button1']")).click();
		

	}

}
