package com.hdfcergo.campaign.car;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class car_insurance_Offer_BuyNow_6th {

	
public static void main(String[] args) throws Exception {
			
			System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			
			driver.get("https://www.hdfcergo.com/campaigns/car-insurance-offer");
			Thread.sleep(2000);
			
			//Inspect form
			
			WebElement nameTextBox= driver.findElement(By.id("txtName"));
			nameTextBox.isDisplayed();
			nameTextBox.isEnabled();
			nameTextBox.sendKeys("hdfc ergo");
			
			WebElement emailTexttBox= driver.findElement(By.id("txtEmail"));
			emailTexttBox.isDisplayed();
			emailTexttBox.isEnabled();
			emailTexttBox.sendKeys("text@gmail.com");
			
			WebElement moNumberTextBox= driver.findElement(By.id("txtMobno"));
			moNumberTextBox.isDisplayed();
			moNumberTextBox.isEnabled();
			moNumberTextBox.sendKeys("8424925955");
			
			WebElement coverageType= driver.findElement(By.xpath("//label[normalize-space()='Not Sure']"));
			coverageType.isDisplayed();
			coverageType.isEnabled();
			coverageType.click();
			
			WebElement buyOnlineBtn= driver.findElement(By.xpath("//input[@id='btnBuyOnlineDivMandatory']"));
			buyOnlineBtn.isDisplayed();
			buyOnlineBtn.isEnabled();
			buyOnlineBtn.click();
	}

}
