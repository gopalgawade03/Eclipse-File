package com.hdfcergo.campaign.travel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class buyTravelInsurancePage_1st {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/buy-travel-insurance");
		Thread.sleep(2000);
		
		WebElement btnClick= driver.findElement(By.xpath("//button[normalize-space()='Buy Now']"));
		btnClick.click();
		
		String actValue= btnClick.getText();
		String expValue= "Travel that extra mile with zero worries";
		
		if(actValue==expValue) {
			System.out.println("Test is Passed");
			}else {
				System.out.println("Test is Failed");
		}
		

	}

}
