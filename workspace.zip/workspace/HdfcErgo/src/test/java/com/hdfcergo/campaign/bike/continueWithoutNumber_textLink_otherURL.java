package com.hdfcergo.campaign.bike;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class continueWithoutNumber_textLink_otherURL {

		public static void main(String[] args) throws InterruptedException {
				
				System.setProperty("webdriver.chrome.driver","C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
				WebDriver driver= new ChromeDriver();
				driver.manage().window().maximize();
				
				driver.get("https://www.hdfcergo.com/campaigns/two-wheeler-insurance-detail");
				Thread.sleep(2000);
			
				driver.findElement(By.xpath("//button[@id='banner-proceed-without-number']")).click();

	}
  
}