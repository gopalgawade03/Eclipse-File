package com.hdfcergo.campaign.cyber;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class planForStudent {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/buy-cyber-sachet-insurance");
		Thread.sleep(2000);
		
		WebElement drp= driver.findElement(By.id("CyberInsurancePlans"));
		drp.click();		
		
		Select drpText=new Select(drp);
		drpText.selectByVisibleText("Plan For Shopaholic");
		Thread.sleep(2000);
		
		driver.findElement(By.id("btnProceed")).click();
	}

}
