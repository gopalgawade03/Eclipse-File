package com.hdfcergo.campaign.allinoneproduct;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class cycber {

public static void main(String[] args) throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\SeleniumJarFiles\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		driver.get("https://www.hdfcergo.com/campaigns/all-in-one-product-new");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//div[@class='topIco']//div[@class='InsuranceIcon InsuranceIcon7']")).click();
		
		WebElement drp= driver.findElement(By.id("sel_Plans"));
		Select drpText=new Select(drp);
		//drpText.selectByVisibleText("Plan For Student");
		//drpText.selectByVisibleText("Plan For Family");
		//drpText.selectByVisibleText("Plan For Working Professional");
		drpText.selectByVisibleText("Plan For Entrepreneur");
		//drpText.selectByVisibleText("Plan For Shopaholic");
		//drpText.selectByVisibleText("Make Your Own Plan");
		Thread.sleep(1000);
		
		driver.findElement(By.id("btnProceed1")).click();
		

	}

}
